module project1 {
	requires java.desktop;
}